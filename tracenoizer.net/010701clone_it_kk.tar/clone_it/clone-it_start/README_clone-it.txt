



startdatabody.pl

liest die namen aus name400.txt

und startet artclone_central.pl

name400.txt
 
name  der k�nstler


db_ies.pl


legt datanbank ies an

artclone_central.pl

mach holt daten verarbeitet sie l�dt webseite rauf und f�llt db