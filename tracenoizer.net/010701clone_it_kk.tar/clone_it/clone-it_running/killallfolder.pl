#/usr/bin/perl
 
 
for ($i= 1;$i < 10;$i++){
system "rm -R $i*";
}    
