#/usr/bin/perl


system "perl makeclone.pl 1";
system "perl makeclone.pl 2";   
system "perl makeclone.pl 3";   
system "perl makeclone.pl 4";   
system "perl makeclone.pl 5";   
system "perl makeclone.pl 6";   
system "perl makeclone.pl 7";   
system "perl makeclone.pl 8";   
